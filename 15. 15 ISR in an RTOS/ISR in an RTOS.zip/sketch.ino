// Experiment 15: ISR in an RTOS - deferred processing and priority handling
#include <Arduino.h>
 
#define BUTTON_PIN 0     // BOOT button on the ESP32 board (active LOW)
#define RUN_CORE   1     // both tasks on one core so priorities compete
 
TaskHandle_t InterruptTaskHandle = NULL;
volatile uint32_t interruptCount = 0;
 
// ---------- Interrupt Service Routine: keep it SHORT ----------
void IRAM_ATTR ButtonISR() {
  interruptCount = interruptCount + 1;
  BaseType_t xHigherPriorityTaskWoken = pdFALSE;
  vTaskNotifyGiveFromISR(InterruptTaskHandle, &xHigherPriorityTaskWoken);
  if (xHigherPriorityTaskWoken) {
    portYIELD_FROM_ISR();      // switch to the woken task immediately
  }
}
 
// ---------- High-priority task: deferred processing ----------
void InterruptTask(void *parameter) {
  while (1) {
    uint32_t pending = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);  // BLOCKED until notified
    Serial.printf("HIGH PRIORITY TASK -> Interrupt Count: %lu (notifications: %lu)\n",
                  (unsigned long)interruptCount, (unsigned long)pending);
    Serial.println("Deferred processing executed.");
    Serial.println("------------------------------");
  }
}
 
// ---------- Low-priority background task ----------
void BackgroundTask(void *parameter) {
  while (1) {
    Serial.println("LOW PRIORITY TASK -> Background processing");
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
 
  Serial.println("=================================");
  Serial.println(" ISR PRIORITY AND DEFERRED PROCESSING");
  Serial.println("=================================");
 
  xTaskCreatePinnedToCore(InterruptTask,  "InterruptTask",  4096, NULL, 3,
                          &InterruptTaskHandle, RUN_CORE);
  xTaskCreatePinnedToCore(BackgroundTask, "BackgroundTask", 4096, NULL, 1,
                          NULL, RUN_CORE);
 
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), ButtonISR, FALLING);
 
  Serial.println("Interrupt configured on GPIO 0.");
  Serial.println("Interrupt Task Priority = 3");
  Serial.println("Background Task Priority = 1");
  Serial.println("Press the BOOT button.");
  Serial.println("=================================");
}
 
void loop() {
  delay(1000);
}
