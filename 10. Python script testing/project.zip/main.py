import serial
import time
 
PORT = "COM3"          # change to the COM port shown in Device Manager
BAUD = 115200
TEST_CYCLES = 5        # number of automated test cycles
TIMEOUT_S = 3          # a cycle FAILS if TEST_SIGNAL is not received in 3 s
 
print("Opening", PORT, "...")
esp32 = serial.serial_for_url(PORT, baudrate=BAUD, timeout=1,
                              dsrdtr=False, rtscts=False)
esp32.dtr = False
esp32.rts = False
print("Connected to ESP32")
time.sleep(3)          # allow the ESP32 to finish booting
 
print("-------------------")
print("Waiting for TEST_SIGNAL...")
print("-------------------")
 
pass_count = 0
fail_count = 0
 
for cycle in range(1, TEST_CYCLES + 1):
    result = "FAIL"
    start = time.time()
    while time.time() - start < TIMEOUT_S:
        data = esp32.readline().decode("utf-8", errors="ignore").strip()
        if data == "":
            continue
        print("Received:", data)
        if data == "TEST_SIGNAL":
            result = "PASS"
            break
        print("Startup/Other Message - Ignored")
 
    if result == "PASS":
        pass_count += 1
    else:
        fail_count += 1
    print("Test", cycle, "Result:", result)
 
esp32.close()
print("-------------------")
print("Test completed.")
print("Total PASS:", pass_count)
print("Total FAIL:", fail_count)
print("-------------------")
