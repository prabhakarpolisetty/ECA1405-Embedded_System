// Experiment 16: Priority inversion and priority inheritance
// Run once with USE_MUTEX 1 (inheritance), then with USE_MUTEX 0 (inversion).
#include <Arduino.h>
 
#define USE_MUTEX 1      // 1 = mutex (priority inheritance), 0 = binary semaphore
#define RUN_CORE  1      // all tasks on one core so they compete for one CPU
 
SemaphoreHandle_t resourceLock;
uint32_t tStart;                     // time 0 = when the tasks are created
#define NOW() (millis() - tStart)
 
// Keep the CPU busy for 'ms' milliseconds (real work, not blocking)
void busyWork(uint32_t ms) {
  uint32_t start = millis();
  while (millis() - start < ms) { }
}
 
// ---------- LOW priority task (P1): holds the shared resource ----------
void LowTask(void *pv) {
  vTaskDelay(pdMS_TO_TICKS(100));
  xSemaphoreTake(resourceLock, portMAX_DELAY);
  Serial.printf("[%4lu ms] LOW    -> resource LOCKED (priority %u)\n",
                NOW(), (unsigned)uxTaskPriorityGet(NULL));
  for (int i = 1; i <= 10; i++) {            // 10 x 100 ms of CPU work
    busyWork(100);
    Serial.printf("[%4lu ms] LOW    -> working %d/10, current priority %u\n",
                  NOW(), i, (unsigned)uxTaskPriorityGet(NULL));
  }
  xSemaphoreGive(resourceLock);
  Serial.printf("[%4lu ms] LOW    -> resource RELEASED, priority now %u\n",
                NOW(), (unsigned)uxTaskPriorityGet(NULL));
  vTaskDelete(NULL);
}
 
// ---------- MEDIUM task (P2): CPU-heavy, never uses the resource ----------
void MediumTask(void *pv) {
  vTaskDelay(pdMS_TO_TICKS(400));
  Serial.printf("[%4lu ms] MEDIUM -> starts 2000 ms of CPU work\n", NOW());
  for (int i = 1; i <= 4; i++) {
    busyWork(500);
    Serial.printf("[%4lu ms] MEDIUM -> working %d/4\n", NOW(), i);
  }
  Serial.printf("[%4lu ms] MEDIUM -> finished\n", NOW());
  vTaskDelete(NULL);
}
 
// ---------- HIGH priority task (P3): needs the same resource ----------
void HighTask(void *pv) {
  vTaskDelay(pdMS_TO_TICKS(300));
  Serial.printf("[%4lu ms] HIGH   -> requests the resource\n", NOW());
  uint32_t t0 = millis();
  xSemaphoreTake(resourceLock, portMAX_DELAY);       // blocks while LOW holds it
  uint32_t waited = millis() - t0;
  Serial.printf("[%4lu ms] HIGH   -> resource LOCKED after waiting %lu ms\n",
                NOW(), (unsigned long)waited);
  xSemaphoreGive(resourceLock);
  Serial.println("==============================================");
  Serial.printf("RESULT: HIGH waited %lu ms (%s)\n", (unsigned long)waited,
                USE_MUTEX ? "mutex, priority inheritance"
                          : "binary semaphore, NO inheritance");
  Serial.println("==============================================");
  vTaskDelete(NULL);
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("==============================================");
  Serial.printf(" PRIORITY INVERSION TEST  (USE_MUTEX = %d)\n", USE_MUTEX);
  Serial.println(" LOW = P1, MEDIUM = P2, HIGH = P3, all on core 1");
  Serial.println("==============================================");
 
  if (USE_MUTEX) {
    resourceLock = xSemaphoreCreateMutex();          // supports inheritance
  } else {
    resourceLock = xSemaphoreCreateBinary();         // no inheritance
    xSemaphoreGive(resourceLock);                    // make it available
  }
  if (resourceLock == NULL) {
    Serial.println("Creation failed");
    while (1) delay(1000);
  }
 
  tStart = millis();
  xTaskCreatePinnedToCore(LowTask,    "Low",    4096, NULL, 1, NULL, RUN_CORE);
  xTaskCreatePinnedToCore(MediumTask, "Medium", 4096, NULL, 2, NULL, RUN_CORE);
  xTaskCreatePinnedToCore(HighTask,   "High",   4096, NULL, 3, NULL, RUN_CORE);
}
 
void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));
}
