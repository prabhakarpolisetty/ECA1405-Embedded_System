// Experiment 14: RTOS software timers and event groups
#include <Arduino.h>
#include "freertos/timers.h"
#include "freertos/event_groups.h"
 
#define TIMER1_EVENT (1 << 0)    // BIT 0
#define TIMER2_EVENT (1 << 1)    // BIT 1
 
EventGroupHandle_t eventGroup;
TimerHandle_t timer1, timer2;
 
// Timer callbacks run in the FreeRTOS timer service task: keep them short.
void Timer1Callback(TimerHandle_t xTimer) {
  xEventGroupSetBits(eventGroup, TIMER1_EVENT);
}
 
void Timer2Callback(TimerHandle_t xTimer) {
  xEventGroupSetBits(eventGroup, TIMER2_EVENT);
}
 
void EventTask(void *parameter) {
  uint32_t lastSync = millis();
  while (1) {
    Serial.println();
    Serial.println("Waiting for BIT 0 and BIT 1...");
    EventBits_t bits = xEventGroupWaitBits(
        eventGroup,
        TIMER1_EVENT | TIMER2_EVENT,
        pdTRUE,                // clear the bits on exit
        pdTRUE,                // wait for BOTH bits
        portMAX_DELAY);
    uint32_t now = millis();
    Serial.printf("Both Timer Events detected at %lu ms (interval %lu ms)\n",
                  (unsigned long)now, (unsigned long)(now - lastSync));
    lastSync = now;
    if (bits & TIMER1_EVENT) Serial.println("Timer 1 Event -> BIT 0");
    if (bits & TIMER2_EVENT) Serial.println("Timer 2 Event -> BIT 1");
    Serial.println("Synchronization complete.");
    Serial.println("------------------------------");
  }
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("=================================");
  Serial.println(" RTOS TIMER AND EVENT GROUP TEST");
  Serial.println("=================================");
 
  eventGroup = xEventGroupCreate();
  timer1 = xTimerCreate("Timer1", pdMS_TO_TICKS(1000), pdTRUE, NULL, Timer1Callback);
  timer2 = xTimerCreate("Timer2", pdMS_TO_TICKS(2000), pdTRUE, NULL, Timer2Callback);
  if (eventGroup == NULL || timer1 == NULL || timer2 == NULL) {
    Serial.println("ERROR: creation failed");
    while (1) delay(1000);
  }
 
  Serial.println("Event Group created.");
  Serial.println("Timer 1 = 1000 ms -> BIT 0");
  Serial.println("Timer 2 = 2000 ms -> BIT 1");
  Serial.println("Both events required for synchronization.");
  Serial.println("=================================");
 
  xTaskCreate(EventTask, "EventTask", 4096, NULL, 1, NULL);
  xTimerStart(timer1, 0);       // pdTRUE above = periodic (auto-reload)
  xTimerStart(timer2, 0);
}
 
void loop() {
  delay(1000);
}
