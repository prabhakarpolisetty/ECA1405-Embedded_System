// Experiment 11: Task creation, task states and priority assignment
#include <Arduino.h>
 
#define RUN_CORE 1   // all tasks on one core, so they compete for one CPU
 
TaskHandle_t hHigh, hMed, hLow;
volatile uint32_t highCount = 0, medCount = 0, lowCount = 0;
 
const char* stateName(TaskHandle_t t) {
  switch (eTaskGetState(t)) {
    case eRunning:   return "Running";
    case eReady:     return "Ready";
    case eBlocked:   return "Blocked";
    case eSuspended: return "Suspended";
    default:         return "Deleted";
  }
}
 
void HighTask(void *pv) {
  while (1) {
    highCount = highCount + 1;
    Serial.printf("HIGH   | Priority: %u | Count: %lu | RUNNING -> BLOCKED (500 ms)\n",
                  (unsigned)uxTaskPriorityGet(NULL), (unsigned long)highCount);
    vTaskDelay(pdMS_TO_TICKS(500));          // task enters BLOCKED state
  }
}
 
void MediumTask(void *pv) {
  while (1) {
    medCount = medCount + 1;
    Serial.printf("MEDIUM | Priority: %u | Count: %lu | RUNNING -> BLOCKED (1000 ms)\n",
                  (unsigned)uxTaskPriorityGet(NULL), (unsigned long)medCount);
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}
 
void LowTask(void *pv) {
  while (1) {
    lowCount = lowCount + 1;
    Serial.printf("LOW    | Priority: %u | Count: %lu | RUNNING -> BLOCKED (1500 ms)\n",
                  (unsigned)uxTaskPriorityGet(NULL), (unsigned long)lowCount);
    vTaskDelay(pdMS_TO_TICKS(1500));
  }
}
 
// Monitor: every 3 s prints counts and the state of each task.
// It suspends LowTask at 12 s and resumes it at 18 s.
void MonitorTask(void *pv) {
  uint32_t t = 0;
  while (1) {
    vTaskDelay(pdMS_TO_TICKS(3000));
    t += 3;
    if (t == 12) { vTaskSuspend(hLow); Serial.println(">>> LowTask SUSPENDED"); }
    if (t == 18) { vTaskResume(hLow);  Serial.println(">>> LowTask RESUMED"); }
    Serial.printf("[MONITOR] t = %2lu s | Counts H/M/L = %lu/%lu/%lu | States H:%s M:%s L:%s\n",
                  (unsigned long)t, (unsigned long)highCount, (unsigned long)medCount,
                  (unsigned long)lowCount, stateName(hHigh), stateName(hMed), stateName(hLow));
  }
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("========================================");
  Serial.println("FreeRTOS TASK PRIORITY EXPERIMENT");
  Serial.println("Priority: HIGH=3, MEDIUM=2, LOW=1");
  Serial.println("========================================");
 
  xTaskCreatePinnedToCore(HighTask,    "HighTask",   4096, NULL, 3, &hHigh, RUN_CORE);
  xTaskCreatePinnedToCore(MediumTask,  "MediumTask", 4096, NULL, 2, &hMed,  RUN_CORE);
  xTaskCreatePinnedToCore(LowTask,     "LowTask",    4096, NULL, 1, &hLow,  RUN_CORE);
  xTaskCreatePinnedToCore(MonitorTask, "Monitor",    4096, NULL, 4, NULL,   RUN_CORE);
}
 
void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));
}
