#include <systemc>
#include <tlm>
#include <tlm_utils/simple_initiator_socket.h>
#include <tlm_utils/simple_target_socket.h>
using namespace sc_core;
using namespace tlm;
using namespace std;
 
// Target: a processing station that needs 10 ns per part
struct Station : sc_module {
  tlm_utils::simple_target_socket<Station> socket;
  SC_CTOR(Station) : socket("socket") {
    socket.register_b_transport(this, &Station::b_transport);
  }
  void b_transport(tlm_generic_payload& trans, sc_time& delay) {
    int* part = (int*) trans.get_data_ptr();
    cout << sc_time_stamp() << " : Station processing part " << *part << endl;
    delay += sc_time(10, SC_NS);              // processing time
    trans.set_response_status(TLM_OK_RESPONSE);
  }
};
 
// Initiator: a conveyor controller that feeds three parts
struct Conveyor : sc_module {
  tlm_utils::simple_initiator_socket<Conveyor> socket;
  SC_CTOR(Conveyor) : socket("socket") {
    SC_THREAD(feed);
  }
  void feed() {
    int parts[3] = {101, 102, 103};
    for (int i = 0; i < 3; i++) {
      tlm_generic_payload trans;
      sc_time delay = SC_ZERO_TIME;
      trans.set_command(TLM_WRITE_COMMAND);
      trans.set_data_ptr(reinterpret_cast<unsigned char*>(&parts[i]));
      trans.set_data_length(sizeof(int));
      socket->b_transport(trans, delay);
      wait(delay);                             // advance time by processing delay
      cout << sc_time_stamp() << " : Part " << parts[i] << " completed" << endl;
    }
  }
};
 
int sc_main(int argc, char* argv[]) {
  Conveyor conveyor("conveyor");
  Station station("station");
  conveyor.socket.bind(station.socket);
  sc_start();
  return 0;
}
