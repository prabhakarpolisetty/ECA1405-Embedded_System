// Experiment 17: Memory management in an RTOS
// Part A heap, Part B memory leak, Part C stack high-water mark, Part D memory pool
#include <Arduino.h>
 
#define BLOCK_SIZE 32
#define NUM_BLOCKS 4
 
// ---------------- Fixed-size memory pool ----------------
static uint8_t pool[NUM_BLOCKS][BLOCK_SIZE];   // 4 x 32 = 128 bytes, fixed
static bool    used[NUM_BLOCKS];               // false = free
 
void *poolAlloc(void) {
  for (int i = 0; i < NUM_BLOCKS; i++) {
    if (!used[i]) { used[i] = true; return pool[i]; }
  }
  return NULL;                                 // pool full
}
 
void poolFree(void *p) {
  for (int i = 0; i < NUM_BLOCKS; i++) {
    if (p == pool[i]) { used[i] = false; return; }
  }
}
 
// Uses a large local array, so it needs a lot of stack
void stackHungry(void) {
  volatile uint8_t buffer[1500];
  for (int i = 0; i < 1500; i++) buffer[i] = (uint8_t)i;
  Serial.printf("stackHungry(): buffer[1499] = %u\n", buffer[1499]);
}
 
void MemoryTask(void *pv) {
  // ---------- Part A: heap allocation and release ----------
  Serial.println("\n--- PART A: HEAP ALLOCATION ---");
  size_t before = ESP.getFreeHeap();
  int *data = (int *)pvPortMalloc(10 * sizeof(int));      // request 40 bytes
  size_t after = ESP.getFreeHeap();
  if (data == NULL) { Serial.println("Allocation FAILED"); }
  Serial.printf("Requested          : %u bytes\n", (unsigned)(10 * sizeof(int)));
  Serial.printf("Heap before        : %u bytes\n", (unsigned)before);
  Serial.printf("Heap after         : %u bytes\n", (unsigned)after);
  Serial.printf("Heap reduction     : %u bytes (data + overhead)\n",
                (unsigned)(before - after));
  vPortFree(data);
  Serial.printf("Heap after release : %u bytes\n", (unsigned)ESP.getFreeHeap());
 
  // ---------- Part B: memory leak ----------
  Serial.println("\n--- PART B: MEMORY LEAK (malloc without free) ---");
  void *leak[5];
  size_t start = ESP.getFreeHeap();
  for (int i = 0; i < 5; i++) {
    leak[i] = pvPortMalloc(1024);              // 1 KB, NOT freed here
    size_t nowFree = ESP.getFreeHeap();
    Serial.printf("After leak %d : free heap %u bytes (lost %u)\n",
                  i + 1, (unsigned)nowFree, (unsigned)(start - nowFree));
  }
  for (int i = 0; i < 5; i++) vPortFree(leak[i]);         // clean up
  Serial.printf("After freeing all : free heap %u bytes\n",
                (unsigned)ESP.getFreeHeap());
  Serial.printf("Lowest free heap ever : %u bytes\n",
                (unsigned)ESP.getMinFreeHeap());
 
  // ---------- Part C: stack high-water mark ----------
  Serial.println("\n--- PART C: STACK HIGH-WATER MARK (stack = 4096 bytes) ---");
  UBaseType_t hwm1 = uxTaskGetStackHighWaterMark(NULL);
  Serial.printf("Before stackHungry() : %u bytes never used\n", (unsigned)hwm1);
  stackHungry();
  UBaseType_t hwm2 = uxTaskGetStackHighWaterMark(NULL);
  Serial.printf("After  stackHungry() : %u bytes never used\n", (unsigned)hwm2);
  Serial.printf("Peak stack used      : %u of 4096 bytes\n",
                (unsigned)(4096 - hwm2));
 
  // ---------- Part D: fixed-size memory pool ----------
  Serial.println("\n--- PART D: MEMORY POOL (4 blocks x 32 bytes) ---");
  void *blk[NUM_BLOCKS];
  for (int i = 0; i < NUM_BLOCKS; i++) {
    blk[i] = poolAlloc();
    Serial.printf("Block %d allocated at %p\n", i + 1, blk[i]);
  }
  void *extra = poolAlloc();
  if (extra == NULL) Serial.println("Block 5 : FAILED - pool FULL");
  poolFree(blk[1]);                                        // release block 2 only
  Serial.println("Block 2 released");
  void *again = poolAlloc();
  Serial.printf("New request got %p (%s)\n", again,
                again == blk[1] ? "same block reused" : "other block");
  for (int i = 0; i < NUM_BLOCKS; i++) poolFree(blk[i]);
  Serial.println("All blocks released");
 
  // ---------- Part E: timing - pool vs heap ----------
  Serial.println("\n--- PART E: SPEED, 1000 allocate + free ---");
  uint32_t t0 = micros();
  for (int i = 0; i < 1000; i++) {
    void *p = poolAlloc();
    poolFree(p);
  }
  uint32_t tPool = micros() - t0;
  t0 = micros();
  for (int i = 0; i < 1000; i++) {
    void *p = pvPortMalloc(BLOCK_SIZE);
    vPortFree(p);
  }
  uint32_t tHeap = micros() - t0;
  Serial.printf("Memory pool : %lu us total\n", (unsigned long)tPool);
  Serial.printf("Heap        : %lu us total\n", (unsigned long)tHeap);
 
  Serial.println("\n--- MEMORY TEST COMPLETE ---");
  vTaskDelete(NULL);
}
 
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("================================");
  Serial.println(" RTOS MEMORY MANAGEMENT TEST");
  Serial.println("================================");
  // stack size 4096 is in BYTES on the ESP32
  xTaskCreate(MemoryTask, "MemoryTask", 4096, NULL, 1, NULL);
}
 
void loop() {
  vTaskDelay(pdMS_TO_TICKS(1000));
}
